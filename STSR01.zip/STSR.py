from turtle import window_width

import pygame #подключение модуля для создания игр
import os #подключения модуля, поможет подгружать картинку в игровое окно
import random #УРАААААААААААААААААА

pygame.init()  #инициализация пайгейм

print(pygame.font.get_fonts())
#размер игрового окна
win_width = 1000
win_height = 880

#ширина карточек
card_width = 200
card_height = 300
#размеры врагов
enemy_width = 150
enemy_height = 300

#создание игрового окна
win = pygame.display.set_mode((win_width, win_height))

#задаём название окна
pygame.display.set_caption("Slay the Spire ripoff")

# находить путь к файлу иконке
path_icon = os.path.join(os.path.abspath(__file__ + "/.."), "icon.bmp")

path_fon = os.path.join(os.path.abspath(__file__ + "/.."), "bg.png")

# загружаем иконку для игрового окна
icon = pygame.image.load(path_icon)

fon = pygame.image.load(path_fon)

fon = pygame.transform.scale(fon, (win_width, win_height))
# задаем иконку игрвому окну.
pygame.display.set_icon(icon)
# Класс карты
class Card():
    def __init__(self, width = None, height = None, x = None, y = None, img = None):
        self.WIDTH = width
        self.HEIGHT = height
        self.X = x
        self.Y = y
        self.NAME_IMG = img #имя файла
        self.IMAGE = None #сам файл
        #каждая карта будет иметь свою зону
        self.RECT = pygame.Rect(self.X, self.Y, self.WIDTH, self.HEIGHT)
        self.vbeen_chosen = False
        #у каждой карты свой порядковый номер
        self.NUMBER_CARD = None
        self.starting_Y = self.Y

    def load_img(self): #метод для загрузки карт

        #путь к файлу карты
        path_image = os.path.join(os.path.abspath(__file__ + "/.."), self.NAME_IMG)

        #загрузка карты
        self.IMAGE = pygame.image.load(path_image)

        #размер карты
        self.IMAGE = pygame.transform.scale(self.IMAGE, (self.WIDTH, self.HEIGHT))
    def card_choice(self):
        
        if not self.vbeen_chosen:
            if player_card_choice == self.NUMBER_CARD:
                self.Y = self.Y-50
                self.vbeen_chosen = True
                print(player_card_choice)
        else:
            self.Y = self.starting_Y
            self.vbeen_chosen = False
    def assimilate(self):
        if hero.energy != 0:
            list_card[player_card_choice - 1].type = list_card[-1].type
            list_card[player_card_choice - 1].IMAGE = list_card[-1].IMAGE
            list_card[player_card_choice - 1].NUMBER_CARD = list_card[-1].NUMBER_CARD




            #if player_card_choice == 3 and len(list_card) == 4:
            #    list_card[player_card_choice - 1].type = list_card[player_card_choice].type
            #    list_card[player_card_choice - 1].IMAGE = list_card[player_card_choice].IMAGE
            #    list_card[player_card_choice - 1].NUMBER_CARD = list_card[player_card_choice].NUMBER_CARD
            #    
            #    
            #elif player_card_choice == 2:
            #    list_card[player_card_choice - 1].type = list_card[player_card_choice].type
            #    list_card[player_card_choice - 1].IMAGE = list_card[player_card_choice].IMAGE
            #    list_card[player_card_choice - 1].NUMBER_CARD = list_card[player_card_choice].NUMBER_CARD
            #    if len(list_card) == 4:
            #        list_card[player_card_choice].type = list_card[player_card_choice + 1].type
            #        list_card[player_card_choice].IMAGE = list_card[player_card_choice + 1].IMAGE
            #        list_card[player_card_choice].NUMBER_CARD = list_card[player_card_choice + 1].NUMBER_CARD
            #        
            #        
            #elif player_card_choice == 1:
            #    list_card[player_card_choice - 1].type = list_card[player_card_choice].type
            #    list_card[player_card_choice - 1].IMAGE = list_card[player_card_choice].IMAGE
            #    list_card[player_card_choice - 1].NUMBER_CARD = list_card[player_card_choice].NUMBER_CARD
            #    if len(list_card) == 3:
            #        list_card[player_card_choice].type = list_card[player_card_choice + 1].type
            #        list_card[player_card_choice].IMAGE = list_card[player_card_choice + 1].IMAGE
            #        list_card[player_card_choice].NUMBER_CARD = list_card[player_card_choice + 1].NUMBER_CARD
            #        if len(list_card) == 4:
            #            list_card[player_card_choice + 1].type = list_card[player_card_choice + 2].type
            #            list_card[player_card_choice + 1].IMAGE = list_card[player_card_choice + 2].IMAGE
            #            list_card[player_card_choice + 1].NUMBER_CARD = list_card[player_card_choice + 2].NUMBER_CARD
            #               
                            
            
        
        


class Enemy():
    def __init__(self, width = None, height = None, x = None, y = None, img = None, enemy_hp = None):
        self.WIDTH = width
        self.HEIGHT = height
        self.X = x
        self.Y = y
        self.NAME_IMG = img #имя файла
        self.IMAGE = None #сам файл
        self.enemy_hp = enemy_hp
        #каждая карта будет иметь свою зону
        self.RECT = pygame.Rect(self.X, self.Y, self.WIDTH, self.HEIGHT)

        #у каждой карты свой порядковый номер
        self.NUMBER_CARD = None
        self.enemy_damage = random.randint(15, 20)
        self.Font = pygame.font.Font(None, 28)
       
    def check_alive(self):
        if self.enemy_hp > 0:
            self.text_damage = self.Font.render(str(self.enemy_damage) + " Шкоди", True, (255, 150, 150))
            self.text_hp = self.Font.render(str(self.enemy_hp) + " Життів", True, (255, 100, 100))
            
            win.blit(self.text_damage, (self.X + self.WIDTH//2 - 35, self.Y-10))
            win.blit(self.text_hp, (self.X + self.WIDTH//2 - 40, self.Y+self.HEIGHT + 10))
            if player_enemy_choice == list_enemies[self.NUMBER_ENEMY]:
                self.selected = self.Font.render("\/", True, (0, 200, 200))
                win.blit(self.selected, (self.X + self.WIDTH//2, self.Y - 30))
            win.blit(self.IMAGE, (self.X, self.Y))
        else:
            self.enemy_damage = 0





            
            

    def load_img(self): #метод для загрузки карт

        #путь к файлу карты
        path_image = os.path.join(os.path.abspath(__file__ + "/.."), self.NAME_IMG)

        #загрузка карты
        self.IMAGE = pygame.image.load(path_image)

        #размер карты
        self.IMAGE = pygame.transform.scale(self.IMAGE, (self.WIDTH, self.HEIGHT))


class Player():
    def __init__(self, player_hp = 50, energy = 3, width = 150, height = 300, x = 100, y = enemy_height - 86, img = None):
        self.WIDTH = width
        self.HEIGHT = height
        self.X = x
        self.Y = y
        
        self.player_hp = player_hp
        self.energy = energy
        img = f"character.png"
        self.PLAYER_IMG = img
        self.Font = pygame.font.Font(None, 32)
        

    def check_alive_player(self):
        self.text_energy = self.Font.render(str(self.energy) + " Енергії", True, (0, 255, 255))
        self.text_hp = self.Font.render(str(self.player_hp), True, (255, 100, 100))
        win.blit(self.text_energy, (self.X + self.WIDTH//2 - 20, self.Y-25))
        win.blit(self.text_hp, (self.X + self.WIDTH//2 - 25, self.Y+self.HEIGHT + 10))
        

    def load_img(self): #метод для загрузки карт

        #путь к файлу карты
        path_image = os.path.join(os.path.abspath(__file__ + "/.."), self.PLAYER_IMG)

        #загрузка карты
        self.IMAGE = pygame.image.load(path_image)

        #размер карты
        self.IMAGE = pygame.transform.scale(self.IMAGE, (self.WIDTH, self.HEIGHT))


class Lable():
    def __init__(self, size, color, text_on = None, x = None, y = None, font = None):

        self.SIZE = size
        self.COLOR = color
        self.TEXT = text_on
        self.X = x
        self.Y = y
        self.FONT_text = font


        #Настройки шрифта Font
        self.font_lable = pygame.font.SysFont(self.FONT_text, self.SIZE)   #шрифт и размер
        #поверхность для текста - render
        self.text = self.font_lable.render(self.TEXT, True, self.COLOR) #параметры: текст, сглаживание и цвет
        #отоброжение текста - blit
        win.blit(self.text, (self.X, self.Y))

class Button():
    def __init__(self, x, y, width, height, img = None):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.RECT = pygame.Rect(self.x, self.y, self.width, self.height)
        self.NAME_IMG = img
        self.IMAGE = None #сам файл

    def load_img(self): #метод для загрузки карт

        #путь к файлу карты
        path_image = os.path.join(os.path.abspath(__file__ + "/.."), self.NAME_IMG)

        #загрузка карты
        self.IMAGE = pygame.image.load(path_image)

        #размер карты
        self.IMAGE = pygame.transform.scale(self.IMAGE, (self.width, self.height))

end_turn = Button(x = win_width - 120, y = win_height - card_height - 10, width = 120, height = 50, img = f"end_turn.png")
end_turn.load_img()

#список загруженных спрайтов (карт)
list_card = [] #список карт
list_enemies = [] #список возможных врагов в комнате

current_enemy_hp = None
def create_room():
    global rand_enemy, current_enemy_hp
    x = win_width - 200
    for i in range (1):
        rand_enemy = random.randint(2, 3)

        for i in range(rand_enemy):
            rand_enemy = random.randint(2, 3)
            enemy_type = random.randint(1, 2)
            if enemy_type == 1 or enemy_type == 2:
                current_enemy_hp = random.randint(10, 18)
            enemy_local = Enemy(enemy_width, enemy_height, x, 
                            y = enemy_height - 86,
                            img = f"basic_enemy{enemy_type}.png", enemy_hp=current_enemy_hp)
            num = 1
            list_enemies.append(enemy_local) #добавляем спрайт в список
            list_enemies[-1].load_img() #выгружаем последнюю карту из списка
            list_enemies[-1].NUMBER_ENEMY = len(list_enemies) - 1
            list_enemies[-1].debuffs = []
            x -= enemy_width + 10




        #list_card[-1].NUMBER_CARD = i + 1 #каждая карта получает номер
        






def create_card():  #загружаем карты
    global rand_card
    x = 10
    num = 0
    for i in range(4):
        
        rand_card = random.randint(1, 4) #случайно выбирает карты из колоды

        
        sprite = Card(width = card_width, 
                        height = card_height, 
                        x = x, 
                        y = win_height - card_height - 10,
                        img = f"basic_{rand_card}.png")  

                        #img = f"basic_{i + 1}.png") 

        list_card.append(sprite) #добавляем спрайт в список

        list_card[-1].load_img() #выгружаем последнюю карту из списка

        list_card[-1].NUMBER_CARD = len(list_card)

        list_card[-1].type = rand_card

        list_card[-1].NUMBER = 1 + num #каждая карта получает номер
        print(list_card[-1].NUMBER)
        num += 1
        x += card_width + 20

#def card_use()
hero = Player()
hero.load_img()
create_card() #формируем список карт

create_room()

#таймер
clock = pygame.time.Clock()

#new_card = pygame.USEREVENT #создаём событие
#pygame.time.set_timer(new_card, 3000) #каждую секунду происходит обновление карт.(1000 = 1 секунда)

#способ таймера номер 2
#start_ticks = pygame.time.get_ticks #фиксируем текущее время в милисекундах

score = 0
barrier = 0

ostatochna_cartka = None
player_enemy_choice = None
topor = 0
#цикл игры
def run_game(): 
    game = True #включить
    
    while game:
        global score, list_card, player_card_choice, player_enemy_choice, rand_card, ostatochna_cartka
        global vbeen_chosen


        #second = (pygame.time.get_ticks() - start_ticks // 1000) #проверяем сколько секунд прошло

        #if second % 2 == 0:
        #    print("new")
        
        #win.fill((255, 137, 145)) #заливка фона
        win.blit(fon, (0, 0))

        #отрисовка кажого спрайта в списке
        for card in list_card:    #перебираем все карты списка
            win.blit(card.IMAGE, (card.X, card.Y)) #выводим карту (задаём название файла И положение)

        for enemy in list_enemies:
        
            enemy.check_alive()
            hero.check_alive_player()
        win.blit(hero.IMAGE, (hero.X, hero.Y))
        win.blit(end_turn.IMAGE, (end_turn.x, end_turn.y))
        #фпс
        clock.tick(60)

        for event in pygame.event.get(): #перебор всех событий
            if event.type == pygame.QUIT: #ЕСЛИ выход, то
                game = False #выключть
            elif event.type == pygame.MOUSEBUTTONDOWN: #если вышка нажата, то
                x, y = event.pos #фиксирует положение курсора в переменные
                for card in list_card:
                    if card.RECT.collidepoint(x, y):#если х и у совпадают с х и у карты, то
                        print("Карта нажата", card.NUMBER_CARD)
                        player_card_choice = card.NUMBER_CARD
                        ostatochna_cartka = card.type
                        print("Тип картки: " + str(ostatochna_cartka))
                        for card in list_card:
                            card.card_choice()
                        

                for enemy in list_enemies:
                    if enemy.RECT.collidepoint(x, y):#если х и у совпадают с х и у карты, то
                        print("Враг нажат", enemy.NUMBER_ENEMY)
                        player_enemy_choice = enemy.NUMBER_ENEMY
                        print("Життів у ворога:", list_enemies[player_enemy_choice].enemy_hp)
                        list_enemies[player_enemy_choice].check_alive()

                if end_turn.RECT.collidepoint(x, y):
                    for enemy in list_enemies:
                        hero.player_hp -= enemy.enemy_damage
                        print(hero.player_hp)
                        list_card.clear()
                        create_card()
                        hero.energy = 3
                                    
                        
                        
                if player_enemy_choice != None and ostatochna_cartka != None:
                    for card in list_card:
                        if ostatochna_cartka == 1:
                            
                            #print(list_enemies[player_enemy_choice].enemy_hp)
                            
                            print("Видалена картка номер: " , player_card_choice)
                            list_card[player_card_choice - 1].assimilate()
                            if hero.energy != 0:
                                hero.energy -= 1
                                list_card.pop(-1)
                                list_enemies[player_enemy_choice].enemy_hp -= 10

                            ostatochna_cartka = None
                            player_enemy_choice = None
                            #list_card.pop(player_card_choice - 1)
                            #list_card.insert(player_card_choice - 1, player_card_choice)
                            print(list_card)
                            
                        elif ostatochna_cartka == 2:
                            list_card[player_card_choice - 1].assimilate()
                            if hero.energy != 0:
                                hero.energy -= 1
                                list_card.pop(-1)
                                hero.player_hp += 10
                            ostatochna_cartka = None
                            player_enemy_choice = None

                        elif ostatochna_cartka == 3:
                            list_enemies[player_enemy_choice].debuffs.append("Target")
                            print(list_enemies[player_enemy_choice].debuffs)
                            list_card[player_card_choice - 1].assimilate()
                            if hero.energy != 0:
                                hero.energy -= 1
                                list_card.pop(-1)
                            ostatochna_cartka = None
                            player_enemy_choice = None

                        elif ostatochna_cartka == 4:
                            list_card[player_card_choice - 1].assimilate()
                            if hero.energy != 0:
                                hero.energy -= 1
                                list_card.pop(-1)
                                hero.player_hp += 10
                                for deubuff in list_enemies[player_enemy_choice].debuffs:
                                    if deubuff == "Target":
                                        list_enemies[player_enemy_choice].enemy_hp -= 12
                                list_enemies[player_enemy_choice].enemy_hp -= 6

                            ostatochna_cartka = None
                            player_enemy_choice = None
                                

                            
                            


        pygame.display.flip()


run_game() # запуск функции